from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)

# File to store registrations
REGISTRATIONS_FILE = 'registrations.json'

def load_registrations():
    if os.path.exists(REGISTRATIONS_FILE):
        with open(REGISTRATIONS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_registration(data):
    registrations = load_registrations()
    data['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    registrations.append(data)
    with open(REGISTRATIONS_FILE, 'w') as f:
        json.dump(registrations, f, indent=2)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()

        # Basic validation
        required = ['firstName', 'lastName', 'phone', 'city', 'bike']
        for field in required:
            if not data.get(field, '').strip():
                return jsonify({'success': False, 'message': f'{field} is required'}), 400

        # Save to JSON file
        save_registration(data)

        return jsonify({
            'success': True,
            'message': 'Registration successful!',
            'whatsapp_link': 'https://chat.whatsapp.com/HbRgZJa1Rqm5Kbso36WDWf?mode=hqctcla'
        })

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/registrations')
def view_registrations():
    """Admin page to view all registrations"""
    registrations = load_registrations()
    return render_template('registrations.html', registrations=registrations)

if __name__ == '__main__':
    app.run(debug=True)
