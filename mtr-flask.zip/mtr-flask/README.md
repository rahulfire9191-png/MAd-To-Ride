# 🏍️ Mad To Ride (MTR) — Flask Website

Riding community website for **Mad To Ride** founded by **Rahul "Madmax" Choudhari**.

---

## 📁 Project Structure

```
mtr-flask/
├── app.py                  # Flask backend
├── requirements.txt        # Python dependencies
├── registrations.json      # Auto-created when first rider registers
└── templates/
    ├── index.html          # Main website
    └── registrations.html  # Admin: view all sign-ups
```

---

## 🚀 How to Run

### Step 1 — Install Python
Make sure Python 3 is installed:
```bash
python --version
```

### Step 2 — Install Flask
```bash
pip install flask
```
Or using requirements.txt:
```bash
pip install -r requirements.txt
```

### Step 3 — Run the App
```bash
python app.py
```

### Step 4 — Open in Browser
```
http://localhost:5000/
```

---

## 📋 Pages

| URL                  | Description                        |
|---------------------|------------------------------------|
| `/`                 | Main MTR website                   |
| `/registrations`    | Admin panel — view all sign-ups    |

---

## 💾 How Registrations Work

1. Rider fills the form on the website
2. Form data is sent to `/register` via POST (JSON)
3. Flask saves it to `registrations.json`
4. A success modal appears with the WhatsApp group link
5. Rider is redirected to join the WhatsApp group

View all registrations at: `http://localhost:5000/registrations`

---

## 🌐 Deploy Online (Free)

### Option A — Render.com
1. Push this folder to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your GitHub repo
4. Set build command: `pip install -r requirements.txt`
5. Set start command: `python app.py`
6. Deploy!

### Option B — Railway.app
1. Push to GitHub
2. Go to [railway.app](https://railway.app) → New Project
3. Deploy from GitHub repo

---

## 🔧 WhatsApp Group Link
The WhatsApp group link is set in `app.py`:
```python
'whatsapp_link': 'https://chat.whatsapp.com/HbRgZJa1Rqm5Kbso36WDWf?mode=hqctcla'
```

---

*Mad To Ride — Where the road calls and real riders answer. 🔥*
